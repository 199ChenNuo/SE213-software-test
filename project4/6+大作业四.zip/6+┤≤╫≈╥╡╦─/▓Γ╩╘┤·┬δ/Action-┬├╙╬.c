Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_cookie("appFloatCnt=3; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600305979.1560600406435.1560600305979.1560600406435.0.0.0.3.3; DOMAIN=vacations.ctrip.com");

	web_add_cookie("gad_city=bfc57e4d16854aac15936b76ba41619a; DOMAIN=vacations.ctrip.com");

	web_add_cookie("MKT_Pagesource=PC; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_RDG=283512ed64ea60289c1b77b0f623e6a733; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_gid=GA1.2.1564785990.1560600010; DOMAIN=vacations.ctrip.com");

	web_add_cookie("StartCity_Pkg=PkgStartCity=2; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_ga=GA1.2.1415380112.1560600010; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560599996890.1.3; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_RGUID=5a5258b1-1ea5-42b9-8b0b-50413a016914; DOMAIN=vacations.ctrip.com");

	web_add_cookie("__zpspc=9.1.1560600033.1560600406.3%234%7C%7C%7C%7C%7C%23; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_RSG=vAKfU4BMIf5KaM0w44KBi8; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_RF1=58.247.22.137; DOMAIN=vacations.ctrip.com");

	web_add_cookie("appFloatCnt=3; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600305979.1560600406435.1560600305979.1560600406435.0.0.0.3.3; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("gad_city=bfc57e4d16854aac15936b76ba41619a; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("MKT_Pagesource=PC; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_RDG=283512ed64ea60289c1b77b0f623e6a733; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_gid=GA1.2.1564785990.1560600010; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("StartCity_Pkg=PkgStartCity=2; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_ga=GA1.2.1415380112.1560600010; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560599996890.1.3; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_RGUID=5a5258b1-1ea5-42b9-8b0b-50413a016914; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("__zpspc=9.1.1560600033.1560600406.3%234%7C%7C%7C%7C%7C%23; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_RSG=vAKfU4BMIf5KaM0w44KBi8; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_RF1=58.247.22.137; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("sid=98af883a2eeb3c6c9ac30575225bdbdf; DOMAIN=dat.gtags.net");

	web_add_cookie("id=228d60cd9bbd00c3||t=1560600384|et=730|cs=002213fd4880d44cf6c6bdb38a; DOMAIN=googleads.g.doubleclick.net");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560605155167.2.4; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_bfs=1.1; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("v=5zk>k>yps-:T1ZCIl@@*; DOMAIN=secure.mediav.com");

	web_add_cookie("uid=wONTI+kRZY8W+hO0vHmCPg==; DOMAIN=s.c-ctrip.com");

	web_add_cookie("BAIDUID=EA27BAB0CE60E891AE4E57B9D00CEE9B:FG=1; DOMAIN=cpro.baidu.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600406435.1560605157890.1560600406435.1560605157890.0.0.0.4.4; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("__zpspc=9.2.1560605157.1560605157.1%234%7C%7C%7C%7C%7C%23; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_gat=1; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("id=228d60cd9bbd00c3||t=1560600384|et=730|cs=002213fd4880d44cf6c6bdb38a; DOMAIN=stats.g.doubleclick.net");

	web_add_cookie("BAIDUID=EA27BAB0CE60E891AE4E57B9D00CEE9B:FG=1; DOMAIN=eclick.baidu.com");

/* Added by Async CodeGen.
ID=LongPoll_0
ScanType = Recording

The following URLs are considered part of this conversation:
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100527%3A547227%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197178&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100525%3A547229%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197174&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100526%3A547230%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197176&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100528%3A547228%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197180&jv=2.6.9

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	LongPoll_0_RequestCB
	LongPoll_0_ResponseCB
 */
	web_reg_async_attributes("ID=LongPoll_0", 
		"Pattern=LongPoll", 
		"URL=https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100527%3A547227%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197178&jv=2.6.9", 
		"RequestCB=LongPoll_0_RequestCB", 
		"ResponseCB=LongPoll_0_ResponseCB", 
		LAST);

/* Added by Async CodeGen.
ID=LongPoll_1
ScanType = Recording

The following URLs are considered part of this conversation:
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100529%3A522110%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217003&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100530%3A502318%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217035&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100529%3A522110%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217083&jv=2.6.9

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	LongPoll_1_RequestCB
	LongPoll_1_ResponseCB
 */
	web_reg_async_attributes("ID=LongPoll_1", 
		"Pattern=LongPoll", 
		"URL=https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100529%3A522110%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217003&jv=2.6.9", 
		"RequestCB=LongPoll_1_RequestCB", 
		"ResponseCB=LongPoll_1_ResponseCB", 
		LAST);

/* Added by Async CodeGen.
ID=LongPoll_2
ScanType = Recording

The following URLs are considered part of this conversation:
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100530%3A502318%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217158&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100530%3A502318%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217067&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100529%3A522110%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217047&jv=2.6.9

TODO - The following callbacks have been added to AsyncCallbacks.c.
Add your code to the callback implementations as necessary.
	LongPoll_2_RequestCB
	LongPoll_2_ResponseCB
 */
	web_reg_async_attributes("ID=LongPoll_2", 
		"Pattern=LongPoll", 
		"URL=https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100530%3A502318%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217158&jv=2.6.9", 
		"RequestCB=LongPoll_2_RequestCB", 
		"ResponseCB=LongPoll_2_ResponseCB", 
		LAST);

/* URLs removed from EXTRARES by Async CodeGen.
ID = LongPoll_0
URLs: 
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100527%3A547227%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197178&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100525%3A547229%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197174&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100526%3A547230%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197176&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100528%3A547228%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605197180&jv=2.6.9
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = LongPoll_1
URLs: 
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100529%3A522110%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217003&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100530%3A502318%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217035&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100529%3A522110%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217083&jv=2.6.9
 */
/* URLs removed from EXTRARES by Async CodeGen.
ID = LongPoll_2
URLs: 
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100530%3A502318%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217158&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100530%3A502318%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217067&jv=2.6.9
	https://s.c-ctrip.com/bf.gif?ac=tl&pi=103045&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D103045%26PositionIdVSAdId%3D100529%3A522110%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.4&duid=&env=online&v=6&mt=1560605217047&jv=2.6.9
 */
	

/* Added by Async CodeGen.
ID = LongPoll_2
 */
	web_stop_async("ID=LongPoll_2", 
		LAST);

/* Added by Async CodeGen.
ID = LongPoll_1
 */
	web_stop_async("ID=LongPoll_1", 
		LAST);

/* Added by Async CodeGen.
ID = LongPoll_0
 */
	web_stop_async("ID=LongPoll_0", 
		LAST);

	web_add_cookie("appFloatCnt=3; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600305979.1560600406435.1560600305979.1560600406435.0.0.0.3.3; DOMAIN=accounts.ctrip.com");

	web_add_cookie("gad_city=bfc57e4d16854aac15936b76ba41619a; DOMAIN=accounts.ctrip.com");

	web_add_cookie("MKT_Pagesource=PC; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_RDG=283512ed64ea60289c1b77b0f623e6a733; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_gid=GA1.2.1564785990.1560600010; DOMAIN=accounts.ctrip.com");

	web_add_cookie("StartCity_Pkg=PkgStartCity=2; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_ga=GA1.2.1415380112.1560600010; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560599996890.1.3; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_RGUID=5a5258b1-1ea5-42b9-8b0b-50413a016914; DOMAIN=accounts.ctrip.com");

	web_add_cookie("__zpspc=9.1.1560600033.1560600406.3%234%7C%7C%7C%7C%7C%23; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_RSG=vAKfU4BMIf5KaM0w44KBi8; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_RF1=58.247.22.137; DOMAIN=accounts.ctrip.com");

	web_url("AjaxGetCookie.ashx", 
		"URL=https://accounts.ctrip.com/member/ajax/AjaxGetCookie.ashx?jsonp=BuildHTML&r=0.995648637237581&encoding=0", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t174.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Access-Control-Request-Headers", 
		"accept, content-type");

	web_add_auto_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://vacations.ctrip.com");

	web_custom_request("hotwords", 
		"URL=https://online.ctrip.com/restapi/soa2/11899/hotwords", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t175.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("searchBoxText", 
		"URL=https://online.ctrip.com/restapi/soa2/11899/searchBoxText", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t176.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("DepartureCity", 
		"URL=https://online.ctrip.com/restapi/soa2/13517/DepartureCity", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t177.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Access-Control-Request-Headers", 
		"cookieorigin, accept, content-type");

	web_custom_request("GetLocationInfo", 
		"URL=https://online.ctrip.com/restapi/soa2/12446/GetLocationInfo", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t178.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Access-Control-Request-Headers", 
		"content-type, x-req-src");

	web_custom_request("getSeckill", 
		"URL=https://online.ctrip.com/restapi/soa2/15292/getSeckill", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t179.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("displayWindow", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t180.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("displayWindow_2", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t181.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("displayWindow_3", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t182.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("NavigationInfo", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/NavigationInfo", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t183.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("displayWindow_4", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t184.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(13);

	web_custom_request("displayWindow_5", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t185.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("appFloatCnt=3; DOMAIN=online.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600305979.1560600406435.1560600305979.1560600406435.0.0.0.3.3; DOMAIN=online.ctrip.com");

	web_add_cookie("gad_city=bfc57e4d16854aac15936b76ba41619a; DOMAIN=online.ctrip.com");

	web_add_cookie("MKT_Pagesource=PC; DOMAIN=online.ctrip.com");

	web_add_cookie("_RDG=283512ed64ea60289c1b77b0f623e6a733; DOMAIN=online.ctrip.com");

	web_add_cookie("_gid=GA1.2.1564785990.1560600010; DOMAIN=online.ctrip.com");

	web_add_cookie("StartCity_Pkg=PkgStartCity=2; DOMAIN=online.ctrip.com");

	web_add_cookie("_ga=GA1.2.1415380112.1560600010; DOMAIN=online.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560605155167.2.4; DOMAIN=online.ctrip.com");

	web_add_cookie("_RGUID=5a5258b1-1ea5-42b9-8b0b-50413a016914; DOMAIN=online.ctrip.com");

	web_add_cookie("__zpspc=9.1.1560600033.1560600406.3%234%7C%7C%7C%7C%7C%23; DOMAIN=online.ctrip.com");

	web_add_cookie("_RSG=vAKfU4BMIf5KaM0w44KBi8; DOMAIN=online.ctrip.com");

	web_add_cookie("_RF1=58.247.22.137; DOMAIN=online.ctrip.com");

	web_add_cookie("_bfs=1.1; DOMAIN=online.ctrip.com");

	web_revert_auto_header("Access-Control-Request-Headers");

	web_revert_auto_header("Access-Control-Request-Method");

	web_add_header("cookieorigin", 
		"https://vacations.ctrip.com");

	web_custom_request("GetLocationInfo_2", 
		"URL=https://online.ctrip.com/restapi/soa2/12446/GetLocationInfo", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t186.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"PlatformId\":4,\"FrtLocGroup\":[{\"Index\":0,\"LocInfo\":{\"CityId\":2,\"Type\":1}},{\"Index\":1,\"LocInfo\":{\"CityId\":0,\"Type\":1}}],\"contentType\":\"json\"}", 
		LAST);

	web_custom_request("h", 
		"URL=https://cdid.c-ctrip.com/model-poc2/h", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t187.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=requestId=5a5258b11ea542b98b0b50413a016914_26&serverName=https://vacations.ctrip.com", 
		LAST);

	web_add_header("x-req-src", 
		"{\"appId\":\"100018068\",\"from\":\"vacations.ctrip.com/\",\"os\":\"PC\",\"platform\":\"Online\"}");

	web_custom_request("getSeckill_2", 
		"URL=https://online.ctrip.com/restapi/soa2/15292/getSeckill", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t188.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"platformId\":1,\"departureCityId\":2}", 
		LAST);

	web_add_cookie("_RGUID=5a5258b1-1ea5-42b9-8b0b-50413a016914; DOMAIN=cdid.c-ctrip.com");

	web_custom_request("d", 
		"URL=https://cdid.c-ctrip.com/chloro-device/v2/d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t189.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=data=AwdgRgxs3AJgZtATDYAWV0wFNOoIzACcwhha+R8AHNGZvrAKwmFwRgPDVFIDMwAGyxBwJrDHVsTMAEMmg-BFlJsswfCL4+UvHsxMm1PkWqHjo2ZxBJ81O8BSFaL7hmTpUKUp4Ief+CBkQa5sAaRIEO6+"
		"MBpoIvAg6kSCEKmKSPB8TKoCKEhmIIIp2IJoGiCVfCho0mgofNqO2AJ8YChMIGjwnXyCfGhtHWg2xWWCCthdmXw2LcBDYuWJCn3G7c21aIaD9fODi6pbOwO56EyLTOX4gkjpnfVi6NULSGeLNkV8so2NZ0i8IRpFJgCY1IqrQSgxCyGBMaBoEhiARLaDgNGIbjeHjQIjw7jQH58ar-ea5fgLECOLC2WgLTikQiA2xIeo5W7YGYLNAYC5GGSCbDUNA8aiyaiwLREEzFHgQIiS7BUWT4H7yWTgcDUCDaojKDgQQ2wWCMYQgWASiDYfBTJXYCCJTTwWTwBCIYwgJjO4CyCCwWHCwSKQWCT19eAhqmB4ogagTMogWZERNLUE3PHlEhdaR9FLMWaTIQXfqjZOgDATXPCEXxkiVsb5z2C7hMeRdG7LW4TcpCKayC1EKZyMCILrhz2liY2dAi7ZoCAKYg1hQQIpTzP9RRCeIacadO64Qx3CMiG64S"
		"sgZOzcoKCRmG+jEQlYNQHYNqd5biBYDwNhU3DQCadJiJUYwtMS3hLEQ2wNNobChtk-yOIUYHjIkVQ1HUsF5PMlxdD0ib9IMGxXJON6CtMWRzK0JHLE2ayHNgxxXKc+zEhsRxMScewCNslzXF2aQPB0zwNG8uEbJ8-Q-HB-yAukIJgugEKbtCbilA8hF9N+EzlgkSRjGkaSELMxgWGInRgcSLykfGfRqXg0FPiWx6ERGoYUPgiIUQ+B7rjUnTUFS6SJHc+5Ls5syueGQbTKyJRdPGEAFDkAI1MmdxXilbyAvCqQTi8IyjDpcYpLMLx9AMKJtvGrJdMlCzNCYAz4EglkKHV87gvOFxdecFwNE10rRDADgjaQUIyI4RA4EGYBTcI1BgOU82cHGFmTfNwDWgqSgMJt8KwFaEgWYYshIqN4T0Ndl6OLdSBJI4JmQPIxBILAoKcsm9q4PwuA8joYBBetMBqLAIBAA&version=7&serverName="
		"https://vacations.ctrip.com&guid=5a5258b1-1ea5-42b9-8b0b-50413a016914&dg=283512ed64ea60289c1b77b0f623e6a733", 
		LAST);

	web_add_auto_header("x-req-src", 
		"{\"appId\":\"100018068\",\"from\":\"vacations.ctrip.com/\",\"os\":\"PC\",\"platform\":\"Online\"}");

	web_custom_request("displayWindow_6", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t190.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"startCity\":2,\"siteID\":1,\"version\":\"A\",\"catgoryID\":1}", 
		LAST);

	web_custom_request("NavigationInfo_2", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/NavigationInfo", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t191.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"startCity\":2,\"businessUnit\":1,\"type\":0,\"channel\":\"Online\",\"version\":\"A\",\"Category\":0}", 
		LAST);

	web_revert_auto_header("x-req-src");

	web_custom_request("hotwords_2", 
		"URL=https://online.ctrip.com/restapi/soa2/11899/hotwords", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t192.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"source\":\"home\",\"cityID\":2}", 
		LAST);

	web_custom_request("searchBoxText_2", 
		"URL=https://online.ctrip.com/restapi/soa2/11899/searchBoxText", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t193.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"channel\":\"online\",\"page\":1,\"cityID\":2}", 
		LAST);

	web_add_header("x-req-src", 
		"{\"appId\":\"100018068\",\"from\":\"vacations.ctrip.com/\",\"os\":\"PC\",\"platform\":\"Online\"}");

	web_custom_request("displayWindow_7", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t194.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"startCity\":2,\"siteID\":1,\"version\":\"A\",\"catgoryID\":3}", 
		LAST);

	web_custom_request("DepartureCity_2", 
		"URL=https://online.ctrip.com/restapi/soa2/13517/DepartureCity", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t195.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"IsInternal\":true,\"ProductType\":\"AGG\"}", 
		LAST);

	web_add_auto_header("x-req-src", 
		"{\"appId\":\"100018068\",\"from\":\"vacations.ctrip.com/\",\"os\":\"PC\",\"platform\":\"Online\"}");

	web_custom_request("displayWindow_8", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t196.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"startCity\":2,\"siteID\":1,\"version\":\"A\",\"catgoryID\":2}", 
		LAST);

	lr_think_time(5);

	web_custom_request("displayWindow_9", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t197.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"startCity\":2,\"siteID\":1,\"version\":\"A\",\"catgoryID\":4}", 
		LAST);

	web_revert_auto_header("x-req-src");

	web_add_header("Access-Control-Request-Headers", 
		"cookieorigin");

	web_add_auto_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("GetFloatUI", 
		"URL=https://m.ctrip.com/restapi/soa2/10994/json/GetFloatUI?timestamp=1560605157926", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t198.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Access-Control-Request-Headers", 
		"accept, content-type");

	lr_think_time(7);

	web_custom_request("VacationRecommendShips", 
		"URL=https://online.ctrip.com/restapi/soa2/12431/VacationRecommendShips", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t199.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600406435.1560605157890.1560600406435.1560605157890.0.0.0.4.4; DOMAIN=online.ctrip.com");

	web_add_cookie("__zpspc=9.2.1560605157.1560605157.1%234%7C%7C%7C%7C%7C%23; DOMAIN=online.ctrip.com");

	web_add_cookie("_gat=1; DOMAIN=online.ctrip.com");

	web_revert_auto_header("Access-Control-Request-Method");

	web_add_header("x-req-src", 
		"{\"appId\":\"100018068\",\"from\":\"vacations.ctrip.com/\",\"os\":\"PC\",\"platform\":\"Online\"}");

	web_custom_request("displayWindow_10", 
		"URL=https://online.ctrip.com/restapi/soa2/14422/displayWindow", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t200.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"startCity\":2,\"siteID\":1,\"version\":\"A\",\"catgoryID\":5}", 
		LAST);

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600406435.1560605157890.1560600406435.1560605157890.0.0.0.4.4; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_bfs=1.1; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_gat=1; DOMAIN=vacations.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560605155167.2.4; DOMAIN=vacations.ctrip.com");

	web_add_cookie("__zpspc=9.2.1560605157.1560605157.1%234%7C%7C%7C%7C%7C%23; DOMAIN=vacations.ctrip.com");

	web_revert_auto_header("Origin");

	web_add_cookie("SRCHUID=V=2&GUID=5C95426443B1413FB4024B1834B5D38D&dmnchg=1; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20190218; DOMAIN=c.urs.microsoft.com");

	web_add_cookie("_bfi=p1%3D103045%26p2%3D0%26v1%3D4%26v2%3D0; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560605157890.1560605216029.1560605157890.1560605216029.0.0.0.5.5; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_bfs=1.2; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560605155167.2.5; DOMAIN=crm.ws.ctrip.com");

	web_add_cookie("__zpspc=9.2.1560605157.1560605216.2%234%7C%7C%7C%7C%7C%23; DOMAIN=crm.ws.ctrip.com");

	web_url("themetravel", 
		"URL=https://vacations.ctrip.com/themetravel", 
		"Resource=0", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t201.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://c.urs.microsoft.com/l1.dat?cw=636961958490150974&v=3&cv=9.11.17134.0&os=10.0.17134.0.0&pg=4A72F430-B40C-4D36-A068-CE33ADA5ADF9", "Referer=", ENDITEM, 
		"Url=https://crm.ws.ctrip.com/Customer-Market-Proxy/AdCallProxyV2.aspx?biztype=2215&siteids=2&adlist=%5B%7B%22pagecode%22%3A%221%22%2C%22domid%22%3A%22slideBanner%22%2C%22type%22%3A0%7D%5D&fscreen=0", ENDITEM, 
		"Url=https://secure.mediav.com/t?type=3&db=none&qzja=1.191303721.1560600035036.1560605157890.1560605216029.1560605157890.1560605216029.0.0.0.5.5&qzjb=1.1560605216029.1.0.1.0&qzjto=1.1.0&jzqh=vacations.ctrip.com&jzqpt=%E4%B8%BB%E9%A2%98%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%E7%BA%BF%E8%B7%AF%E6%8E%A8%E8%8D%90%E3%80%90%E6%90%BA%E7%A8%8B%E6%97%85%E6%B8%B8%E3%80%91&jzqre=https:%2F%2Fvacations.ctrip.com%2F&qzjhn=0&jzqc="
		"_jzqa%3D1.191303721.1560600035.1560605157.1560605216.5&jzqs=m-26049-0&jzqv=3.3.ctrip.17&jzqrd=1560605216030", ENDITEM, 
		"Url=https://s.c-ctrip.com/bf.gif?ac=g&d="
		"%7B%22c%22%3A%5B600002200%2C%221560599996890.439ulz%22%2C2%2C5%2C%22%22%2C%22%22%2C%22%22%2C%222.6.9%22%2C%2217k9vwc-msycg7-bsebf9%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22online%22%5D%2C%22d%22%3A%7B%22uinfo%22%3A%5B13%2C103045%2C4%2C%22https%3A%2F%2Fvacations.ctrip.com%2Fthemetravel%22%2C1368%2C912%2C%22cl%3D620%2Cckl%3D16%22%2C%22zh-cn%22%2C%22%22%2C%22%22%2C%22https%3A%2F%2Fvacations.ctrip.com%2F%22%2C%22%22%2C0%2C0%2C%22%22%2C%22%22%2C%22%22%2C%222%22%2C%22%22%2C%22%22%2C%22%22%2C"
		"%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22online%22%2C2%2C0%2C%22%7B%5C%22tz%5C%22%3A480%2C%5C%22dt%5C%22%3Afalse%2C%5C%22rg%5C%22%3A%5C%22vAKfU4BMIf5KaM0w44KBi8%5C%22%2C%5C%22lang%5C%22%3A%5C%22%5C%22%7D%22%2C%22%22%2C%22%22%2C%22%22%5D%7D%7D&mt=1560605216622&jv=2.6.9", ENDITEM, 
		"Url=https://dat.gtags.net/imp/dasp3?a=9&ext_args=&vc=2&vt=59&vpc=2&rvt=59&fr=0&vrt=0&ot=4&u=https:%2F%2Fvacations.ctrip.com%2Fthemetravel&sc=1368*912&ch=utf-8&la=zh-CN&ti=%E4%B8%BB%E9%A2%98%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%E7%BA%BF%E8%B7%AF%E6%8E%A8%E8%8D%90%E3%80%90%E6%90%BA%E7%A8%8B%E6%97%85%E6%B8%B8%E3%80%91&v=3.0.0.9&ru=https:%2F%2Fvacations.ctrip.com%2F&t=1&r=0.3645065326596826", ENDITEM, 
		"Url=https://eclick.baidu.com/rt.jpg?t=script&rtid=PWTzPjD&stamp=1560605216044&refer=https%3A%2F%2Fvacations.ctrip.com%2F&word=https%3A%2F%2Fvacations.ctrip.com%2Fthemetravel&origin=ctrip.com", ENDITEM, 
		"Url=https://www.google-analytics.com/collect?v=1&_v=j76&a=25427219&t=pageview&_s=1&dl=https:%2F%2Fvacations.ctrip.com%2Fthemetravel&ul=zh-cn&de=utf-8&dt=%E4%B8%BB%E9%A2%98%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%E7%BA%BF%E8%B7%AF%E6%8E%A8%E8%8D%90%E3%80%90%E6%90%BA%E7%A8%8B%E6%97%85%E6%B8%B8%E3%80%91&sd=24-bit&sr=1368x912&vp=1351x792&je=1&fl=32.0%20r0&_u=AACAAEQ~&jid=&gjid=&cid=1415380112.1560600010&tid=UA-3748357-1&_gid=1564785990.1560600010&z="
		"392581333", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1066331136/?value=0&label=cG9hCIyRngMQgNi7_AM&guid=ON&script=0", ENDITEM, 
		"Url=https://googleads.g.doubleclick.net/pagead/viewthroughconversion/1066331136/?random=1560605216057&cv=9&fst=1560605216057&num=1&guid=ON&resp=GooglemKTybQhCsO&u_h=912&u_w=1368&u_ah=872&u_aw=1368&u_cd=24&u_his=1&u_tz=480&u_java=true&u_nplug=1&u_nmime=2&data=travel_destid%3Dno%20match%3Btravel_pagetype%3Dofferdetail&frm=0&url=https:%2F%2Fvacations.ctrip.com%2Fthemetravel&ref=https:%2F%2Fvacations.ctrip.com%2F&tiba="
		"%E4%B8%BB%E9%A2%98%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%2C%E4%B8%BB%E9%A2%98%E6%97%85%E6%B8%B8%E7%BA%BF%E8%B7%AF%E6%8E%A8%E8%8D%90%E3%80%90%E6%90%BA%E7%A8%8B%E6%97%85%E6%B8%B8%E3%80%91&async=1&rfmt=3&fmt=4", ENDITEM, 
		"Url=https://crm.ws.ctrip.com/Customer-Market-Proxy/Ajax/DyRequest.aspx?v2=true&biztype=2215&pageid=1&callback=G_Ad_DyLoad_1.DyLoad&_rm=0.11508921226134222", ENDITEM, 
		"Url=https://s.c-ctrip.com/bf.gif?ac=tl&pi=600002200&key=sumadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D600002200%26PositionIdVSAdId%3D102272%3A579993-102273%3A579977-102274%3A579334%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.5&duid=&env=online&v=6&mt=1560605231229&jv=2.6.9", ENDITEM, 
		"Url=https://s.c-ctrip.com/bf.gif?ac=tl&pi=600002200&key=pcadpv&val=UserId%3D1560599996890.439ulz%26PageId%3D600002200%26PositionId%3D102272%26AdId%3D579993%26src%3Dhttps%3A%2F%2Fdimg04.c-ctrip.com%2Fimages%2F700k15000000xtxxe78AF_1920_430_454.jpg%26SiteID%3D2%26SiteType%3D&pv=1560599996890.439ulz.2.5&duid=&env=online&v=6&mt=1560605231235&jv=2.6.9", ENDITEM, 
		"Url=https://s.c-ctrip.com/bf.gif?ac=tl&pi=600002200&key=brovserVersion&val=IE11&pv=1560599996890.439ulz.2.5&duid=&env=online&v=6&mt=1560605231223&jv=2.6.9", ENDITEM, 
		"Url=https://s.c-ctrip.com/bf.gif?ac=g&d="
		"%7B%22c%22%3A%5B600002200%2C%221560599996890.439ulz%22%2C2%2C5%2C%22%22%2C%22%22%2C%22%22%2C%222.6.9%22%2C%2217k9vwc-msycg7-bsebf9%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22%22%2C%22online%22%5D%2C%22d%22%3A%7B%22ps%22%3A%5B6%2C1560605176626%2C0%2C1560605176626%2C1560605176626%2C0%2C1560605176674%2C1560605176674%2C1560605176674%2C1560605176674%2C1560605176674%2C1560605212728%2C1560605212730%2C1560605212732%2C1560605212730%2C1560605213373%2C1560605213373%2C1560605213377%2C1560605248210%2C15606052"
		"48211%2C1560605248211%2C0%2C0%5D%7D%7D&mt=1560605248649&jv=2.6.9", ENDITEM, 
		"Url=https://s.c-ctrip.com/bf.gif?ac=tl&pi=600002200&key=pcfloatSuccess&val=pcfloatSuccess3&pv=1560599996890.439ulz.2.5&duid=&env=online&v=6&mt=1560605248437&jv=2.6.9", ENDITEM, 
		LAST);

	web_add_cookie("_bfi=p1%3D103045%26p2%3D0%26v1%3D4%26v2%3D0; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600406435.1560605157890.1560600406435.1560605157890.0.0.0.4.4; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_bfs=1.1; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_gat=1; DOMAIN=accounts.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560605155167.2.4; DOMAIN=accounts.ctrip.com");

	web_add_cookie("__zpspc=9.2.1560605157.1560605157.1%234%7C%7C%7C%7C%7C%23; DOMAIN=accounts.ctrip.com");

	web_add_cookie("ASP.NET_SessionId=xlodaslxrgjxic412drds0hk; DOMAIN=accounts.ctrip.com");

	web_url("AjaxGetCookie.ashx_2", 
		"URL=https://accounts.ctrip.com/member/ajax/AjaxGetCookie.ashx?jsonp=BuildHTML&r=0.7605793301220565&encoding=0", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vacations.ctrip.com/themetravel", 
		"Snapshot=t202.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"https://vacations.ctrip.com");

	web_custom_request("h_2", 
		"URL=https://cdid.c-ctrip.com/model-poc2/h", 
		"Method=POST", 
		"Resource=0", 
		"Referer=https://vacations.ctrip.com/themetravel", 
		"Snapshot=t203.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=requestId=5a5258b11ea542b98b0b50413a016914_27&serverName=https://vacations.ctrip.com", 
		LAST);

	web_custom_request("d_2", 
		"URL=https://cdid.c-ctrip.com/chloro-device/v2/d", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://vacations.ctrip.com/themetravel", 
		"Snapshot=t204.inf", 
		"Mode=HTML", 
		"EncType=application/x-www-form-urlencoded; charset=UTF-8", 
		"Body=data=AwdgRgxs3AJgZtATDYAWV0wFNOoIzACcwhha+28AHNGZvrAKwmFwRgPDVFIDMwAGyxBwJrDHVsTMAEMmg-BFlJsswfCL4+UvHsxMm1PkWqHjo2ZxBJ81O8BSFaL7hmTpUKUp4Ief+CBkQa5sAaRIEO6+"
		"MBpoIvAg6kSCEKmKSPB8TKoCKEhmIIIp2IJoGiCVfCho0mgofNqO2AJ8YChMIGjwnXyCfGhtHWg2xWWCCthdmXw2LcBDYuWJCn3G7c21aIaD9fODi6pbOwO56EyLTOX4gkjpnfVi6NULSGeLNkV8so2NZ0i8IRpFJgCY1IqrQSgxCyGBMaBoEhiARLaDgNGIbjeHjQIjw7jQH58ar-ea5fgLECOLC2WgLTikQiA2xIeo5W7YGYLNAYC5GGSCbDUNA8aiyaiwLREEzFHgQIiS7BEeCyfA-eSycDgagQHVEZQcCBG2CwRjCECwCUQbCUEBK7AQRKaFXwBCIYwgJgq4CyCCwWHCwSKQWCT19eAhqmB4ogagTMogWZERNLUE3PHlEhdaR9FLMWaTIQXfqjZOgDATXPCEXxkiVsb5z2C7hMeRdG7LW4TcpCKayS1EKZyMCILrhz2liY2dAi7ZoCAKYg1hQQIpTzP9RRCeIacadO64Qx3CMiG64S"
		"sgZOzcoKCRmG+jEQlYNQHYNqd5biBYDwNhU3DQKadJiJUYwtMS3hLEQ2wNNobChtk-yOIUYHjIkVQ1HUsF5PMlxdD0ib9IMGxXJON6CtMWRzK0JHLE2ayHNgxxXKc+zEhsRxMScewCNslzXF2aQPB0zwNG8uEbJ8-Q-HB-yAukIJgugEKbtCbilA8hF9N+EzlgkSRjGkaSELMxgWGInRgcSLykfGfRqXg0FPiWx6ERGoYUPgiIUQ+B7rjUnTUFS6SJHc+5Ls5syueGQbTKyJRdPGEAFDkAI1MmdxXilbyAvCqQTi8IyjDpcYpLMLx9AMKJtvGrJdMlCzNCYAz4EglkKHV87gvOFxdecFwNE10rRDAjBPAQUIyI4RA4EGYBTcI1BgOU82cHGFmTfNwA2gqm1MEoIo2JBdB7doEEWa2RCyLCmCtI1d1CBK3BPeKd4Skt1A0GAn0-b+9LKPCvCwKCnLJg6uD8LgPI6N9saiDAv7iEAA&"
		"version=7&serverName=https://vacations.ctrip.com&guid=5a5258b1-1ea5-42b9-8b0b-50413a016914&dg=283512ed64ea60289c1b77b0f623e6a733", 
		LAST);

	web_add_header("Access-Control-Request-Headers", 
		"accept, content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("DepartureCity_3", 
		"URL=https://online.ctrip.com/restapi/soa2/13517/DepartureCity", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t205.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("appFloatCnt=3; DOMAIN=m.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560600406435.1560605157890.1560600406435.1560605157890.0.0.0.4.4; DOMAIN=m.ctrip.com");

	web_add_cookie("gad_city=bfc57e4d16854aac15936b76ba41619a; DOMAIN=m.ctrip.com");

	web_add_cookie("MKT_Pagesource=PC; DOMAIN=m.ctrip.com");

	web_add_cookie("_RDG=283512ed64ea60289c1b77b0f623e6a733; DOMAIN=m.ctrip.com");

	web_add_cookie("_gid=GA1.2.1564785990.1560600010; DOMAIN=m.ctrip.com");

	web_add_cookie("StartCity_Pkg=PkgStartCity=2; DOMAIN=m.ctrip.com");

	web_add_cookie("_ga=GA1.2.1415380112.1560600010; DOMAIN=m.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560605155167.2.4; DOMAIN=m.ctrip.com");

	web_add_cookie("_RGUID=5a5258b1-1ea5-42b9-8b0b-50413a016914; DOMAIN=m.ctrip.com");

	web_add_cookie("__zpspc=9.2.1560605157.1560605157.1%234%7C%7C%7C%7C%7C%23; DOMAIN=m.ctrip.com");

	web_add_cookie("_RSG=vAKfU4BMIf5KaM0w44KBi8; DOMAIN=m.ctrip.com");

	web_add_cookie("_RF1=58.247.22.137; DOMAIN=m.ctrip.com");

	web_add_cookie("_bfs=1.1; DOMAIN=m.ctrip.com");

	web_add_cookie("_gat=1; DOMAIN=m.ctrip.com");

	web_add_header("cookieOrigin", 
		"https://vacations.ctrip.com");

	web_custom_request("GetFloatUI_2", 
		"URL=https://m.ctrip.com/restapi/soa2/10994/json/GetFloatUI?timestamp=1560605157926", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t206.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"PlatformType\":\"pc\",\"pageParameter\":{\"Refer\":\"\",\"UA\":\"Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20Touch%3B%20.NET4.0C%3B%20.NET4.0E%3B%20Tablet%20PC%202.0%3B%20rv%3A11.0)%20like%20Gecko\",\"PageID\":103045,\"VID\":\"1560599996890.439ulz\"},\"marketParameter\":{\"AID\":0,\"SID\":0},\"terminalParameter\":{\"UserID\":\"\",\"CityID\":0},\"pcAuthCodeParamet\":{\"IsGetAuthCode\":true,\"AppID\":\"\",\"Length\":4}}", 
		LAST);

	web_add_header("Access-Control-Request-Headers", 
		"cookieorigin");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_custom_request("GetFloatUI_3", 
		"URL=https://m.ctrip.com/restapi/soa2/10994/json/GetFloatUI?timestamp=1560605216193", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t207.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("VacationRecommendShips_2", 
		"URL=https://online.ctrip.com/restapi/soa2/12431/VacationRecommendShips", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/", 
		"Snapshot=t208.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"FromCityID\":2}", 
		LAST);

	web_add_cookie("_bfi=p1%3D103045%26p2%3D0%26v1%3D4%26v2%3D0; DOMAIN=m.ctrip.com");

	web_add_cookie("appFloatCnt=4; DOMAIN=m.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600110601%7C1.191303721.1560600035036.1560605157890.1560605216029.1560605157890.1560605216029.0.0.0.5.5; DOMAIN=m.ctrip.com");

	web_add_cookie("_bfs=1.2; DOMAIN=m.ctrip.com");

	web_add_cookie("_bfa=1.1560599996890.439ulz.1.1560599996890.1560605155167.2.5; DOMAIN=m.ctrip.com");

	web_add_cookie("__zpspc=9.2.1560605157.1560605216.2%234%7C%7C%7C%7C%7C%23; DOMAIN=m.ctrip.com");

	web_add_header("cookieOrigin", 
		"https://vacations.ctrip.com");

	web_custom_request("GetFloatUI_4", 
		"URL=https://m.ctrip.com/restapi/soa2/10994/json/GetFloatUI?timestamp=1560605216193", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/themetravel", 
		"Snapshot=t209.inf", 
		"Mode=HTML", 
		"EncType=text/plain;charset=UTF-8", 
		"Body={\"PlatformType\":\"pc\",\"pageParameter\":{\"Refer\":\"vacations.ctrip.com\",\"UA\":\"Mozilla%2F5.0%20(Windows%20NT%2010.0%3B%20WOW64%3B%20Trident%2F7.0%3B%20Touch%3B%20.NET4.0C%3B%20.NET4.0E%3B%20Tablet%20PC%202.0%3B%20rv%3A11.0)%20like%20Gecko\",\"PageID\":600002200,\"VID\":\"1560599996890.439ulz\"},\"marketParameter\":{\"AID\":0,\"SID\":0},\"terminalParameter\":{\"UserID\":\"\",\"CityID\":0},\"pcAuthCodeParamet\":{\"IsGetAuthCode\":true,\"AppID\":\"\",\"Length\":4}}", 
		LAST);

	web_add_cookie("__DAYU_PP=un2iN6yZbFrYQz2MJ3I6ffffffff924694289d2c; DOMAIN=www.ctrip.com");

	web_add_cookie("appFloatCnt=2; DOMAIN=www.ctrip.com");

	web_add_cookie("_jzqco=%7C%7C%7C%7C1560600250727%7C1.886630320.1560600249904.1560600251598.1560600264252.1560600251598.1560600264252.undefined.0.0.3.3; DOMAIN=www.ctrip.com");

	web_add_cookie("gad_city=bfc57e4d16854aac15936b76ba41619a; DOMAIN=www.ctrip.com");

	web_add_cookie("MKT_Pagesource=PC; DOMAIN=www.ctrip.com");

	web_add_cookie("_RDG=28cf84fc557656253005047e66dcb0a8dc; DOMAIN=www.ctrip.com");

	web_add_cookie("_gid=GA1.2.682168261.1560600250; DOMAIN=www.ctrip.com");

	web_add_cookie("StartCity_Pkg=PkgStartCity=2; DOMAIN=www.ctrip.com");

	web_add_cookie("_ga=GA1.2.1537073865.1560600250; DOMAIN=www.ctrip.com");

	web_add_cookie("_bfa=1.1560600245201.3448kz.1.1560600245201.1560600245201.1.3; DOMAIN=www.ctrip.com");

	web_add_cookie("_RGUID=a0c44980-8293-4f15-9578-9ed1c55766fb; DOMAIN=www.ctrip.com");

	web_add_cookie("__zpspc=9.1.1560600249.1560600264.3%234%7C%7C%7C%7C%7C%23; DOMAIN=www.ctrip.com");

	web_add_cookie("_abtest_userid=b1b85732-1ff4-443c-87ae-0be836569f82; DOMAIN=www.ctrip.com");

	web_add_cookie("_RSG=Lyqa22OI43AxRsL57jduL9; DOMAIN=www.ctrip.com");

	web_add_cookie("_RF1=58.247.22.137; DOMAIN=www.ctrip.com");

	web_custom_request("DepartureCity_4", 
		"URL=https://online.ctrip.com/restapi/soa2/13517/DepartureCity", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://vacations.ctrip.com/themetravel", 
		"Snapshot=t210.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"IsInternal\":true,\"ProductType\":\"AGG\"}", 
		EXTRARES, 
		"Url=https://www.ctrip.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	web_add_cookie("SRCHUID=V=2&GUID=5C95426443B1413FB4024B1834B5D38D&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20190218; DOMAIN=iecvlist.microsoft.com");

	web_revert_auto_header("Origin");

	web_add_header("UA-CPU", 
		"AMD64");

	lr_think_time(21);

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1478281996/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t211.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}